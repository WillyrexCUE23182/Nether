/*
 * UART_Menu_Pot_Ascii.c
 *
 * Created: 24/04/2025
 * Author: Willy Ulises Cuellar Bendfeldt
 * Description:
 *   - Al arrancar env�a el men� al PC sin actualizar LEDs:
 *       �Hola! Soy Jarviss tu asistente, �Qu� quieres hacer?
 *       - Leer Potenciometro (Enviar 0)
 *       - Enviar Ascii (Enviar 1)
 *   - Si recibe '0':  
 *       � Lee ADC en A7, env�a por terminal  
 *         "La lectura del potenci�metro es : <valor>\r\n"  
 *       � Repite el men�.  
 *   - Si recibe '1':  
 *       � Env�a "Escriba caracter Ascii: "  
 *       � Espera el siguiente byte, lo muestra en LEDs (PB0�PB5, PC0�PC1)  
 *       � Repite el men�.  
 *   - LEDs s�lo actualizan en la opci�n ASCII, nunca durante env�o de men� ni de potenci�metro.
 */

#define F_CPU 16000000UL
#include <avr/io.h>
#include <avr/interrupt.h>
#include <util/delay.h>

/*�� Prototipos ��*/
void setup(void);
void initUART(uint32_t baud);
void initADC(void);
void uartSend(char c);
void uartSendString(const char *s);
void uartSendLed(char c);
static inline void displayByte(uint8_t val);
uint16_t readADC7(void);
void printUInt(uint16_t v);
void sendMenu(void);

/*�� Variables ISR ? main ��*/
volatile uint8_t recChar = 0;
volatile uint8_t recFlag = 0;

/*�� Estados ��*/
typedef enum {
    STATE_MENU,
    STATE_POT,
    STATE_ASCII
} state_t;

/*�� main ��*/
int main(void)
{
    setup();

    state_t state = STATE_MENU;

    while (1)
    {
        if (recFlag) {
            char cmd = recChar;
            recFlag = 0;

            switch (state)
            {
                case STATE_MENU:
                    if (cmd == '0') {
                        // Leer potenci�metro
                        uint16_t v = readADC7();
                        uartSendString("La lectura del potenci�metro es : ");
                        printUInt(v);
                        uartSendString("\r\n\r\n");
                        sendMenu();
                    }
                    else if (cmd == '1') {
                        // Preparar ASCII
                        uartSendString("Escriba caracter Ascii: ");
                        state = STATE_ASCII;
                    }
                    break;

                case STATE_ASCII:
                    // Mostrar en LEDs
                    displayByte((uint8_t)cmd);
                    uartSendLed(cmd);  // opcional eco si se desea
                    uartSendString("\r\n\r\n");
                    sendMenu();
                    state = STATE_MENU;
                    break;

                default:
                    break;
            }
        }
    }
}

/*�� setup, initUART, initADC ��*/
void setup(void)
{
    cli();
    // LEDs: PB0�PB5, PC0�PC1
    DDRB = 0x3F;
    DDRC |= (1 << PC0) | (1 << PC1);
    // ADC: A7 como entrada
    initADC();
    initUART(9600);
    sei();

    // Enviar men� inicial
    sendMenu();
}

void initUART(uint32_t baud)
{
    uint16_t ubrr = (F_CPU/(16UL*baud)) - 1;
    UBRR0H = ubrr >> 8;
    UBRR0L = ubrr & 0xFF;
    UCSR0C = (1 << UCSZ01) | (1 << UCSZ00);      // 8N1
    UCSR0B = (1 << TXEN0) | (1 << RXEN0)          // TX y RX habilitados
           | (1 << RXCIE0);                      // Interrupci�n RX
}

void initADC(void)
{
    // Vref = AVCC, canal ADC7
    ADMUX  = (1 << REFS0) | (1 << MUX2) | (1 << MUX1) | (1 << MUX0);
    ADCSRA = (1 << ADEN)
           | (1 << ADPS2) | (1 << ADPS1) | (1 << ADPS0);  // prescaler 128
}

/*�� Env�o de men� (sin LEDs) ��*/
void sendMenu(void)
{
    uartSendString("�Hola! Soy Jarviss tu asistente, �Qu� quieres hacer?\r\n");
    uartSendString("- Leer Potenci�metro (Enviar 0)\r\n");
    uartSendString("- Enviar Ascii   (Enviar 1)\r\n\r\n");
}

/*�� Transmisi�n b�sica (sin LEDs) ��*/
void uartSend(char c)
{
    while (!(UCSR0A & (1 << UDRE0)));
    UDR0 = c;
}

/*�� Transmitir y actualizar LEDs ��*/
void uartSendLed(char c)
{
    uartSend(c);
    displayByte((uint8_t)c);
}

/*�� Enviar cadena ��*/
void uartSendString(const char *s)
{
    while (*s) {
        uartSend(*s++);
    }
}

/*�� Mostrar byte en LEDs bit7?PC1, bit6?PC0, bits5�0?PB5�PB0 ��*/
static inline void displayByte(uint8_t val)
{
    uint8_t pc = 0;
    if (val & (1 << 7)) pc |= (1 << PC1);
    if (val & (1 << 6)) pc |= (1 << PC0);
    PORTC = (PORTC & ~0x03) | pc;
    PORTB = val & 0x3F;
}

/*�� Lee ADC7 (A7) ��*/
uint16_t readADC7(void)
{
    // ya est� seleccionado canal 7
    ADCSRA |= (1 << ADSC);
    while (ADCSRA & (1 << ADSC));
    return ADC;
}

/*�� Imprime valor decimal en terminal ��*/
void printUInt(uint16_t v)
{
    char buf[6];
    uint8_t i = 0;
    if (v == 0) {
        uartSend('0');
        return;
    }
    while (v) {
        buf[i++] = '0' + (v % 10);
        v /= 10;
    }
    while (i--) {
        uartSend(buf[i]);
    }
}

/*�� ISR RX ��*/
ISR(USART_RX_vect)
{
    recChar = UDR0;
    recFlag = 1;
}
